<?php
class M_data extends CI_Model{





}