<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penjualan extends CI_Controller {

		function __construct(){
		parent::__construct();
		if($this->session->userdata('status2') != "loggg"){
			redirect(base_url("login"));
		}
		$this->load->model('m_penjualan');
	}

	public function index()
	{
		$x['data_penjualan']=$this->m_penjualan->get_all_penjualan();
		$x['sidebar']="penjualan";
		$this->load->view('header',$x);
		$this->load->view('sidebar');
		$this->load->view('penjualan/penjualan');
		$this->load->view('footer');
	}

	public function tambah($id)
	{
		$x['id_penjualan']=$id;
		$x['sidebar']="penjualan";
		$this->load->view('header',$x);
		$this->load->view('sidebar');
		$this->load->view('penjualan/tambah');
		$this->load->view('footer');
	}

	public function edit($id)
	{
		$x['id_penjualan']=$id;
		$x['sidebar']="penjualan";
		$x['edit_penjualan']=$this->db->query("SELECT * FROM penjualan,menu_makanan,pegawai where  penjualan.id_barang=menu_makanan.id_menu_makanan AND penjualan.id_pegawai=pegawai.id_pegawai AND penjualan.id_penjualan='$id'")->row_array();
		$this->load->view('header',$x);
		$this->load->view('sidebar');
		$this->load->view('penjualan/edit');
		$this->load->view('footer');
	}

	public function lihat()
	{
		$x['data_penjualan']=$this->m_penjualan->get_all_penjualan();
		$x['sidebar']="penjualan2";
		$this->load->view('header',$x);
		$this->load->view('sidebar');
		$this->load->view('penjualan/lihat');
		$this->load->view('footer');
	}

	public function lihat2()
	{
		$x['data_penjualan']=$this->m_penjualan->get_all_penjualan();
		$x['sidebar']="penjualan3";
		$this->load->view('header',$x);
		$this->load->view('sidebar');
		$this->load->view('penjualan/lihat2');
		$this->load->view('footer');
	}

	public function lihat3()
	{
		$x['data_penjualan']=$this->m_penjualan->get_all_penjualan();
		$x['sidebar']="penjualan4";
		$this->load->view('header',$x);
		$this->load->view('sidebar');
		$this->load->view('penjualan/lihat3');
		$this->load->view('footer');
	}

	public function lihat4()
	{
		$x['data_penjualan']=$this->m_penjualan->get_all_penjualan();
		$x['sidebar']="penjualan5";
		$this->load->view('header',$x);
		$this->load->view('sidebar');
		$this->load->view('penjualan/lihat4');
		$this->load->view('footer');
	}

	public function lihat5()
	{
		$x['data_penjualan']=$this->m_penjualan->get_all_penjualan();
		$x['sidebar']="penjualan6";
		$this->load->view('header',$x);
		$this->load->view('sidebar');
		$this->load->view('penjualan/lihat5');
		$this->load->view('footer');
	}

	public function filter()
	{	
		$tgl1=$this->input->post('tgl1');
		$tgl2=$this->input->post('tgl2');
		$x['tgl1']=$this->input->post('tgl1');
		$x['tgl2']=$this->input->post('tgl2');
		$x['data_penjualan']=$this->db->query("SELECT * FROM penjualan,menu_makanan,pegawai where penjualan.id_barang=menu_makanan.id_menu_makanan AND penjualan.id_pegawai=pegawai.id_pegawai AND date(tanggal_jual) BETWEEN '$tgl1' AND '$tgl2' order by tanggal_jual asc");
		$this->load->view('penjualan/cetak_filter',$x);
	}

	public function filter2()
	{	
		$tahun=$this->input->post('tahun');
		$x['tahun']=$this->input->post('tahun');
		$this->load->view('penjualan/cetak_filter2',$x);
	}
	public function filter22()
	{	
		$tahun=$this->input->post('tahun');
		$bulan=$this->input->post('bulan');
		$x['tahun']=$this->input->post('tahun');
		$x['bulan']=$this->input->post('bulan');
		if ($this->input->post('bulan')=="Januari") {
			$x['bln']=1;
		}elseif ($this->input->post('bulan')=="Februari") {
			$x['bln']=2;
		}elseif ($this->input->post('bulan')=="Maret") {
			$x['bln']=3;
		}elseif ($this->input->post('bulan')=="April") {
			$x['bln']=4;
		}elseif ($this->input->post('bulan')=="Mei") {
			$x['bln']=5;
		}elseif ($this->input->post('bulan')=="Juni") {
			$x['bln']=6;
		}elseif ($this->input->post('bulan')=="Juli") {
			$x['bln']=7;
		}elseif ($this->input->post('bulan')=="Agustus") {
			$x['bln']=8;
		}elseif ($this->input->post('bulan')=="September") {
			$x['bln']=9;
		}elseif ($this->input->post('bulan')=="Oktober") {
			$x['bln']=10;
		}elseif ($this->input->post('bulan')=="November") {
			$x['bln']=11;
		}elseif ($this->input->post('bulan')=="Desember") {
			$x['bln']=12;
		}
		$this->load->view('penjualan/cetak_filter22',$x);
	}
	public function filter3()
	{	
		$tahun=$this->input->post('tahun');
		$x['tahun']=$this->input->post('tahun');
		$this->load->view('penjualan/cetak_filter3',$x);
	}
	public function filter4()
	{	
		$tahun=$this->input->post('tahun');
		$x['tahun']=$this->input->post('tahun');
		$this->load->view('penjualan/cetak_filter4',$x);
	}
	public function filter5()
	{	
		$tahun=$this->input->post('tahun');
		$x['tahun']=$this->input->post('tahun');
		$this->load->view('penjualan/cetak_filter5',$x);
	}

	public function cetak()
	{	
		$x['data_penjualan']=$this->m_penjualan->get_all_penjualan();
		$this->load->view('penjualan/cetak',$x);
	}

		public function simpan_barang()
	{	
			$id_penjualan=$this->input->post('id_penjualan');
			if(empty($this->input->post('id_pegawai'))){
				$this->session->set_flashdata('gll', 'Record is Added Successfully!');
				redirect(base_url('penjualan/tambah/'.$id_penjualan));
			}
			$data2['id_penjualan'] = $this->input->post('id_penjualan');
			$data2['id_pegawai'] = $this->input->post('id_pegawai');
			$data2['id_barang'] = $this->input->post('id_barang');
			$data2['jumlah_jual'] = $this->input->post('jumlah_jual');
			$this->db->insert('barang_list', $data2);
			redirect(base_url('penjualan/tambah/'.$id_penjualan));
	}

		public function simpan_barang2()
	{
			$id_penjualan=$this->input->post('id_penjualan');
			$data2['id_penjualan'] = $this->input->post('id_penjualan');
			$data2['id_pegawai'] = $this->input->post('id_pegawai');
			$data2['id_barang'] = $this->input->post('id_barang');
			$data2['jumlah_jual'] = $this->input->post('jumlah_jual');

			$this->db->insert('barang_list', $data2);
			redirect(base_url('penjualan/edit/'.$id_penjualan));
			
			
	}

		public function simpan_penjualan()
	{

		$id_penjualan=$this->input->post('id_penjualan');
		$nn=0;
		$id_barang1=0;
		$jumlah_jual1=0;
		$id_barang2=0;
		$jumlah_jual2=0;
		$id_barang3=0;
		$jumlah_jual3=0;
		foreach ($this->db->query("SELECT * FROM barang_list where id_penjualan='$id_penjualan'")->result_array() as $key) {
			if($nn==0){
				$id_barang=$key['id_barang'];
				$jumlah_jual=$key['jumlah_jual'];
			}
			if($nn==1){
				$id_barang1=$key['id_barang'];
				$jumlah_jual1=$key['jumlah_jual'];
			}
			if($nn==2){
				$id_barang2=$key['id_barang'];
				$jumlah_jual2=$key['jumlah_jual'];
			}
			if($nn==3){
				$id_barang3=$key['id_barang'];
				$jumlah_jual3=$key['jumlah_jual'];
			}
			$nn=$nn+1;
		}
		

		$id_barang=$id_barang;
		$data_brg=$this->db->query("SELECT * FROM menu_makanan where id_menu_makanan='$id_barang'")->row_array();
		$totall=$data_brg['harga']*$jumlah_jual;

		

		if(!empty($id_barang1)){
			$data_brg=$this->db->query("SELECT * FROM menu_makanan where id_menu_makanan='$id_barang1'")->row_array();
			$totall=$totall+($data_brg['harga']*$jumlah_jual1);
			$data["id_barang1"] = $id_barang1;
			$data["jumlah_jual1"] = $jumlah_jual1;
		}

		if(!empty($id_barang2)){
			$data_brg=$this->db->query("SELECT * FROM menu_makanan where id_menu_makanan='$id_barang2'")->row_array();
			$totall=$totall+($data_brg['harga']*$jumlah_jual2);
			$data["id_barang2"] = $id_barang2;
			$data["jumlah_jual2"] = $jumlah_jual2;
		}

		if(!empty($id_barang3)){
			$data_brg=$this->db->query("SELECT * FROM menu_makanan where id_menu_makanan='$id_barang3'")->row_array();
			$totall=$totall+($data_brg['harga']*$jumlah_jual3);
			$data["id_barang3"] = $id_barang3;
			$data["jumlah_jual3"] = $jumlah_jual3;
		}

		
				$data["id_penjualan"] = $id_penjualan;
				$data["jumlah_jual"] = $jumlah_jual;
				$data["id_barang"] = $id_barang;
				$data["id_pegawai"] = $this->input->post('id_pegawai');
				$data["tanggal_jual"] = $this->input->post('tanggal_jual');
					$grandtotal=str_replace(".", "", $this->input->post('grandtotal'));
		$diskon=str_replace(".", "", $this->input->post('diskon'));
		$bayar=str_replace(".", "", $this->input->post('bayar'));
		$kembalian=str_replace(".", "", $this->input->post('kembalian'));
		$data["total"] = $grandtotal;
		$data["diskon"] = $diskon;
		$data["bayar"] = $bayar;
		$data["kembalian"] = $kembalian;

				
				
					$result = $this->m_penjualan->add_penjualan($data);



					if($result){
						$this->session->set_flashdata('berhasil_simpan', 'Record is Added Successfully!');
						redirect(base_url('penjualan'));
					}
	}


	


		public function update_penjualan()
	{
		$id = $this->input->post('id_penjualan'); 
			

					
		$id_penjualan=$this->input->post('id_penjualan');
		$nn=0;
		$id_barang1=0;
		$jumlah_jual1=0;
		$id_barang2=0;
		$jumlah_jual2=0;
		$id_barang3=0;
		$jumlah_jual3=0;
		foreach ($this->db->query("SELECT * FROM barang_list where id_penjualan='$id_penjualan'")->result_array() as $key) {
			if($nn==0){
				$id_barang=$key['id_barang'];
				$jumlah_jual=$key['jumlah_jual'];
			}
			if($nn==1){
				$id_barang1=$key['id_barang'];
				$jumlah_jual1=$key['jumlah_jual'];
			}
			if($nn==2){
				$id_barang2=$key['id_barang'];
				$jumlah_jual2=$key['jumlah_jual'];
			}
			if($nn==3){
				$id_barang3=$key['id_barang'];
				$jumlah_jual3=$key['jumlah_jual'];
			}
			$nn=$nn+1;
		}
		

		$id_barang=$id_barang;
		$data_brg=$this->db->query("SELECT * FROM menu_makanan where id_menu_makanan='$id_barang'")->row_array();
		$totall=$data_brg['harga']*$jumlah_jual;

		

		if(!empty($id_barang1)){
			$data_brg=$this->db->query("SELECT * FROM menu_makanan where id_menu_makanan='$id_barang1'")->row_array();
			$totall=$totall+($data_brg['harga']*$jumlah_jual1);
			$data["id_barang1"] = $id_barang1;
			$data["jumlah_jual1"] = $jumlah_jual1;
		}

		if(!empty($id_barang2)){
			$data_brg=$this->db->query("SELECT * FROM menu_makanan where id_menu_makanan='$id_barang2'")->row_array();
			$totall=$totall+($data_brg['harga']*$jumlah_jual2);
			$data["id_barang2"] = $id_barang2;
			$data["jumlah_jual2"] = $jumlah_jual2;
		}

		if(!empty($id_barang3)){
			$data_brg=$this->db->query("SELECT * FROM menu_makanan where id_menu_makanan='$id_barang3'")->row_array();
			$totall=$totall+($data_brg['harga']*$jumlah_jual3);
			$data["id_barang3"] = $id_barang3;
			$data["jumlah_jual3"] = $jumlah_jual3;
		}

		
				$data["id_penjualan"] = $id_penjualan;
				$data["jumlah_jual"] = $jumlah_jual;
				$data["id_barang"] = $id_barang;
				$data["id_pegawai"] = $this->input->post('id_pegawai');
				$data["tanggal_jual"] = $this->input->post('tanggal_jual');
					$grandtotal=str_replace(".", "", $this->input->post('grandtotal'));
		$diskon=str_replace(".", "", $this->input->post('diskon'));
		$bayar=str_replace(".", "", $this->input->post('bayar'));
		$kembalian=str_replace(".", "", $this->input->post('kembalian'));
		$data["total"] = $grandtotal;
		$data["diskon"] = $diskon;
		$data["bayar"] = $bayar;
		$data["kembalian"] = $kembalian;
					
				
					$result = $this->m_penjualan->edit_penjualan($data,$id);
					if($result){
						$this->session->set_flashdata('berhasil_edit', 'Record is Added Successfully!');
						redirect(base_url('penjualan'));
					}
	}

	function hapus_penjualan(){
		$kode=$this->input->post('kode');
		$id_penjualan=$this->input->post('kode');
		


		$this->db->query("DELETE FROM barang_list where id_penjualan='$kode'");
		$this->m_penjualan->hapus_penjualan($kode);
		echo $this->session->set_flashdata('berhasil_hapus','berhasil_hapus');
		redirect('penjualan');
	}

	function hapusperbarang($id_barang,$id_penjualan,$stat){
		$this->db->query("DELETE FROM barang_list where id_barang='$id_barang' AND id_penjualan='$id_penjualan'");
		redirect(base_url('penjualan/'.$stat.'/'.$id_penjualan));
	}

	public function fungsitambah(){
        $id_barang = $this->input->post('id_barang');
        $barang = $this->db->query("SELECT * FROM menu_makanan where id_menu_makanan = '$id_barang' ")->row();
        $lists = "<input readonly id='harga_jual1' value='".number_format((int)$barang->harga,0,',','.')."' name='harga' type='text' class='form-control'>";
        $callback = array('list_barang'=>$lists); 
        echo json_encode($callback); 
    }
}