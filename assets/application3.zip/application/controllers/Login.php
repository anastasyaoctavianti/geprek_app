<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

		function __construct(){
		parent::__construct();
	}

	public function index()
	{
		$this->load->view('login');
	}
	public function reg()
	{
		$this->load->view('register');
	}



	function aksi_login(){

		$username = $this->input->post('username');
		$password = $this->input->post('password');

        $result = $this->db->get_where('pengguna', ['username' => $username])->row_array();

        // jika usernya ada
        if ($result) {
                if (password_verify($password, $result['password'])) {
                    $data_session = array(
							'id_pengguna2' => $result['id_pengguna'],
							'username2' => $result['username'],
							'nama_lengkap' => $result['nama_lengkap'],
							'foto' => "",
							'level' => $result['level'],
						 	'status2' => "loggg"
						);
					$this->session->set_userdata($data_session);
					redirect("dashboard");
                } else {
                    $this->session->set_flashdata('pw_salah', ' ');
					redirect("login");
                }
           
        }  else{
			$this->session->set_flashdata('username_salah', ' ');
			redirect("login");
		}

	}


			public function logout(){
			$this->session->sess_destroy();
			redirect("login");
		}
}
