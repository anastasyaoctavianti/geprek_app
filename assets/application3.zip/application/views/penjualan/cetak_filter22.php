<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
  <?php 
function rupiah($angka){
  
  $hasil_rupiah = "Rp " . number_format($angka,0,',','.');
  return $hasil_rupiah;
}
?>

  <?php
function tgl_indo($tanggal)
{
    $bulan = array(
        1 =>   'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    );
    $pecahkan = explode('-', $tanggal);

    // variabel pecahkan 0 = tanggal
    // variabel pecahkan 1 = bulan
    // variabel pecahkan 2 = tahun

    return $pecahkan[2] . ' ' . $bulan[(int) $pecahkan[1]] . ' ' . $pecahkan[0];
}

 function Terbilang($x)   
 {   
  $bilangan = array("", "Satu", "Dua", "Tiga", "Empat", "Lima", "Enam", "Tujuh", "Delapan", "Sembilan", "Sepuluh", "Sebelas");   
  if ($x < 12)   
   return " " . $bilangan[$x];   
  elseif ($x < 20)   
   return Terbilang($x - 10) . "belas";   
  elseif ($x < 100)   
   return Terbilang($x / 10) . " Puluh" . Terbilang($x % 10);   
  elseif ($x < 200)   
   return " seratus" . Terbilang($x - 100);   
  elseif ($x < 1000)   
   return Terbilang($x / 100) . " Ratus" . Terbilang($x % 100);   
  elseif ($x < 2000)   
   return " seribu" . Terbilang($x - 1000);   
  elseif ($x < 1000000)   
   return Terbilang($x / 1000) . " Ribu" . Terbilang($x % 1000);   
  elseif ($x < 1000000000)   
   return Terbilang($x / 1000000) . " Juta" . Terbilang($x % 1000000);    
 } 
?>
<body onLoad="window.print()">
      <table border="0" align="center" width="100%">
        <tr align="center">
            <td>
                 <img width="100px" src="<?= base_url() ?>assets/logo2.png">
            </td>
            <td>
                <font style="margin-right: 100px;" size="5">AYAM GEPREK SA'I BANJARBARU</font><br>
                <font style="margin-right: 100px;" size="3">Jl. Karang Anyar 1, Loktabat Utara, Kec. Banjarbaru Utara, Kota Banjar Baru, Kalimantan Selatan 70714</font><br>
                <font style="margin-right: 100px;" size="3">Telp. (0821) 6961 2018</font>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <hr size="3px" color="black">
            </td>
        </tr>
    </table>



    <div style="text-align: center; ">
        <font size="3"><b><u>LAPORAN DATA LABA RUGI TAHUN <?php echo $tahun;?> BULAN <?php echo strtoupper($bulan);?></u></b></font><br>
    </div>
    <br>
<br>
  <!--   <div style="text-align: center;">
        <font size="2"><b><u> RINGKASAN BIAYA</u></b></font><br>
    </div> -->


<table border="0"  style="margin-left: 80px; font-size: 11pt;font-family: 'Times New Roman';  "  class="table " >
  <div> 
  <tbody>
 
  <tr style="vertical-align: top; text-align: left;">
      <td width="300px"><b>PEMASUKAN</b></td>
      <td></td> 
 </tr>
  <?php $totall=0; $total2=0; $no=1; $laba=0; foreach ($this->db->query("SELECT * FROM penjualan,menu_makanan,pegawai where penjualan.id_barang=menu_makanan.id_menu_makanan AND penjualan.id_pegawai=pegawai.id_pegawai AND YEAR(tanggal_jual) = '$tahun' AND MONTH(tanggal_jual) = '$bln'")->result_array() as $i) :
                                            $id_penjualan=$i['id_penjualan'];

                                            

                                            $laba=$laba+$i['total'];

                                          ?>
                                           
                                          

         <?php endforeach ?>


  <tr style="vertical-align: top; text-align: left;">
      <td >Pendapatan Penjualan</td>
      <td width="150px">-</td>
      <td> <?php echo rupiah($laba);?></td> 
 </tr>





  </tbody>
</div>
</table>
<hr>
  <table border="0"  style="margin-left: 80px; font-size: 11pt;font-family: 'Times New Roman';  "  class="table " >
  <div> 
  <tbody>
 
  <tr style="vertical-align: top; text-align: left;">
      <td width="300px"><b>PENGELUARAN</b></td>
      <td></td> 
 </tr>
 <?php $summmp=0;
 foreach ($this->db->query("SELECT *,SUM(biaya_pengeluaran) as hasil FROM pengeluaran where YEAR(tanggal_pengeluaran) = '$tahun' AND MONTH(tanggal_pengeluaran) = '$bln'  GROUP by nama_pengeluaran")->result_array() as $i) :
                                            $summmp=$summmp+$i['hasil'];

                ?>
 <tr style="vertical-align: top; text-align: left;">
      <td ><?php echo $i['nama_pengeluaran'];?></td>
      <td ></td>
      <td > <?php echo rupiah($i['hasil']);?></td> 
 </tr>
  <?php endforeach ?>
  <tr style="vertical-align: top; text-align: left;">
      <td >Complement Karyawan</td>
      <td ></td>
      

      <?php 
      $jumkr2=$this->db->query("SELECT * FROM complement_karyawan,menu_makanan where complement_karyawan.id_menu_makanan=menu_makanan.id_menu_makanan AND YEAR(tanggal_ambil) = '$tahun' AND MONTH(tanggal_ambil) = '$bln'")->num_rows();
      if ($jumkr2==0) {
          $qwjelk=0;
      }else{
           $jumkr=$this->db->query("SELECT * FROM complement_karyawan,menu_makanan where complement_karyawan.id_menu_makanan=menu_makanan.id_menu_makanan AND YEAR(tanggal_ambil) = '$tahun' AND MONTH(tanggal_ambil) = '$bln'")->row_array();  
           $qwjelk=$jumkr['total'];
      }
      ?>
      <td > <?php echo rupiah($qwjelk);?></td> 
 </tr>
  </tbody>
</div>
</table>


<hr>
<table border="0"  style="margin-left: 80px; font-size: 11pt;font-family: 'Times New Roman';  "  class="table " >
  <div> 
  <tbody>
 <tr style="vertical-align: top; text-align: left;">
      <td width="300px">Total </td>
      <td width="150px">-</td>
      <td> <?php echo rupiah($laba-($summmp-$qwjelk));?></td> 
 </tr>
 
  </tbody>
</div>
</table>
<hr>

    <!-- AKHIRAN HALAMAN -->


    <!-- MULAI HALAMAN -->

    <br><br><br>

<div style="text-align: left; display: inline-block; float: right; margin-right: 50px;">
        <label>
            Banjarbaru, <?php  echo tgl_indo(date('Y-m-d')) ?>
            <br>
            <p style="text-align: center;">
                <b>Owner</b>
            </p>
            <br><br><br>
            <p style="text-align: center;">
                <b><u>Dea Nita</u></b><br>
            </p>
        </label>
    </div> 
</body>

</html>

