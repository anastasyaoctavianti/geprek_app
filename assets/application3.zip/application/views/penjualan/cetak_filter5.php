<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
  <style type="text/css">
    @media print{@page {size: landscape}}
  </style>
  <?php 
function rupiah($angka){
  
  $hasil_rupiah = "Rp " . number_format($angka,0,',','.');
  return $hasil_rupiah;
}
?>

  <?php
function tgl_indo($tanggal)
{
    $bulan = array(
        1 =>   'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    );
    $pecahkan = explode('-', $tanggal);

    // variabel pecahkan 0 = tanggal
    // variabel pecahkan 1 = bulan
    // variabel pecahkan 2 = tahun

    return $pecahkan[2] . ' ' . $bulan[(int) $pecahkan[1]] . ' ' . $pecahkan[0];
}?>
<body onLoad="window.print()">
      <table border="0" align="center" width="100%">
        <tr align="center">
            <td>
                 <img width="100px" src="<?= base_url() ?>assets/logo2.png">
            </td>
            <td>
                <font style="margin-right: 100px;" size="5">AYAM GEPREK SA'I BANJARBARU</font><br>
                <font style="margin-right: 100px;" size="3">Jl. Karang Anyar 1, Loktabat Utara, Kec. Banjarbaru Utara, Kota Banjar Baru, Kalimantan Selatan 70714</font><br>
                <font style="margin-right: 100px;" size="3">Telp. (0821) 6961 2018</font>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <hr size="3px" color="black">
            </td>
        </tr>
    </table>




    <br>
    <div style="text-align: center; ">
        <font size="3"><b><u>LAPORAN NERACA SALDO TAHUN <?php echo $tahun;?></u></b></font><br>
    </div>
    <br>

    <br>
    <table border="1" cellspacing="0" width="100%" style="font-size: 12px;">
        <thead style="background-color: #d5eacf; text-align: center; ">
  <tr>
                                                        <th>KETERANGAN</th>
                                                        <th>DEBIT</th>
                                                        <th>KREDIT</th>
                                                     </tr>
                                                </thead>
                                                 <tbody>
 <?php  $data_penjualan=$this->db->query("SELECT *,SUM(jumlah_jual*harga) as hasil FROM penjualan,menu_makanan,pegawai where penjualan.id_menu_makanan=menu_makanan.id_menu_makanan AND penjualan.id_pegawai=pegawai.id_pegawai AND YEAR(penjualan.tanggal_jual)='$tahun'")->row_array();
           ?>
           
  <?php $hasil3=0; foreach ($this->db->query("SELECT *,SUM(biaya_pengeluaran) hasil FROM pengeluaran where YEAR(pengeluaran.tanggal_pengeluaran)='$tahun'")->result_array() as $key):
        $hasil3=$hasil3+$key['hasil'];?>
        <?php endforeach;?>
       <tr>
           <td>MODAL</td>
           <td></td>
           <td><?php echo rupiah(($hasil3)-$data_penjualan['hasil']);?></td>
       </tr>
       <tr>
           <td>PENJUALAN</td>
           <td></td>
          
           <td><?php echo rupiah($data_penjualan['hasil']);?></td>
       </tr>
      
      
        <?php  foreach ($this->db->query("SELECT *,SUM(biaya_pengeluaran) as biaya_pengeluaran2 FROM pengeluaran where YEAR(pengeluaran.tanggal_pengeluaran)='$tahun' group by nama_pengeluaran")->result_array() as $key):?>
         <tr>
           <td><?php echo strtoupper($key['nama_pengeluaran']);?></td>
           <td><?php echo rupiah($key['biaya_pengeluaran2']);?></td>
           <td></td>
        </tr>
        <?php endforeach;?>
       
       <tr>
           <td>TOTAL</td>
           <td><?php echo rupiah($hasil3);?></td>
           <td><?php echo rupiah($hasil3);?></td>
        
       </tr>

                
                </tbody>
              </table>


    <br><br><br>

 <div style="text-align: left; display: inline-block; float: right; margin-right: 50px;">
        <label>
            Banjarbaru, <?php  echo tgl_indo(date('Y-m-d')) ?>
            <br>
            <p style="text-align: center;">
                <b>Owner</b>
            </p>
            <br><br><br>
            <p style="text-align: center;">
                <b><u>Dea Nita</u></b><br>
            </p>
        </label>
    </div> 
   
</body>

</html>

