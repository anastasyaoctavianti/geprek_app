
    <!-- END: Main Menu-->

    <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <!-- Dashboard Ecommerce Starts -->
                <section id="dashboard-ecommerce">

    <div class="row">

                        <div class="col-lg-12 col-sm-12 col-12">
                            <div class="card">
                                    <center>
                                    <div class="avatar bg-rgba-primary p-50 m-0" style="margin-top: 8px!important;">
                                        <div class="avatar-content" >
                                            <img src="<?php echo base_url();?>/assets/logo2.png" width="80px">
                                        </div>
                                    </div>
                                    <h2 class="text-bold-700 mt-1">AYAM GEPREK SA'I BANJARBARU</h2>
                                  <img src="<?php echo base_url();?>/assets/toko3.png" width="100%" height="500px">
                                </center>
                            </div>
                                <br>
                        </div>

  

                      </div>
                    



                    
                </section>
                <!-- Dashboard Ecommerce ends -->

            </div>
        </div>
    </div>
    <!-- END: Content-->

