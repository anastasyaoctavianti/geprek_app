

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <!-- BEGIN: Footer-->
    <footer class="footer footer-static footer-light">
        <p class="clearfix blue-grey lighten-2 mb-0"><span class="float-md-left d-block d-md-inline-block mt-25">COPYRIGHT &copy; <?php echo date('Y');?> APLIKASI PENJUALAN DAN KEUANGAN PADA AYAM GEPREK SA'I BANJARBARU BERBASIS WEB </span>
           
        </p>
    </footer>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src="<?php echo base_url();?>/assets/template/app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo base_url();?>/assets/template/app-assets/vendors/js/charts/apexcharts.min.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo base_url();?>/assets/template/app-assets/js/core/app-menu.js"></script>
    <script src="<?php echo base_url();?>/assets/template/app-assets/js/core/app.js"></script>
    <script src="<?php echo base_url();?>/assets/template/app-assets/js/scripts/components.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="<?php echo base_url();?>/assets/template/app-assets/js/scripts/pages/dashboard-ecommerce.js"></script>
    <!-- END: Page JS-->

     <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo base_url();?>/assets/template/app-assets/vendors/js/tables/datatable/pdfmake.min.js"></script>
    <script src="<?php echo base_url();?>/assets/template/app-assets/vendors/js/tables/datatable/vfs_fonts.js"></script>
    <script src="<?php echo base_url();?>/assets/template/app-assets/vendors/js/tables/datatable/datatables.min.js"></script>
    <script src="<?php echo base_url();?>/assets/template/app-assets/vendors/js/tables/datatable/datatables.buttons.min.js"></script>
    <script src="<?php echo base_url();?>/assets/template/app-assets/vendors/js/tables/datatable/buttons.html5.min.js"></script>
    <script src="<?php echo base_url();?>/assets/template/app-assets/vendors/js/tables/datatable/buttons.print.min.js"></script>
    <script src="<?php echo base_url();?>/assets/template/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>/assets/template/app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js"></script>
    <!-- END: Page Vendor JS-->

     <!-- BEGIN: Page JS-->
    <script src="<?php echo base_url();?>/assets/template/app-assets/js/scripts/datatables/datatable.js"></script>

     <script src="<?php echo base_url();?>assets/alert/query.js"></script>
<script type="text/javascript">
    $( '.uang' ).mask('00.000.000.000', {reverse: true});
</script>
    <!-- END: Page JS-->
</body>
<!-- END: Body-->

</html>


<script>
  $(document).ready(function(){ 
   
    
    $("#kd_konsumen").change(function(){ 

      $.ajax({
        type: "POST", 
        url: "<?php echo base_url("/barang/carikon"); ?>", 
        data: {kd_konsumen : $("#kd_konsumen").val()}, 
        dataType: "json",
        beforeSend: function(e) {
          if(e && e.overrideMimeType) {
            e.overrideMimeType("application/json;charset=UTF-8");
          }
        },
        success: function(response){ 
          $("#kd_penjualan").html(response.list_barang).show();
        },
        error: function (xhr, ajaxOptions, thrownError) { 
          alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); 
        }
      });


    });

   


  });
  </script>



<script>
  $(document).ready(function(){ 
   
    
    $("#kd_penjualan").change(function(){ 

      $.ajax({
        type: "POST", 
        url: "<?php echo base_url("/menu_makanan/carihrg"); ?>", 
        data: {kd_penjualan : $("#kd_penjualan").val()}, 
        dataType: "json",
        beforeSend: function(e) {
          if(e && e.overrideMimeType) {
            e.overrideMimeType("application/json;charset=UTF-8");
          }
        },
        success: function(response){ 
          $("#hasilretur").html(response.list_barang).show();
        },
        error: function (xhr, ajaxOptions, thrownError) { 
          alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); 
        }
      });


    });

   


  });
  </script>

   <script>
  $(document).ready(function(){ 
    $("#kd_barang").change(function(){ 
     
      $.ajax({
        type: "POST", // Method pengiriman data bisa dengan GET atau POST
        url: "<?php echo base_url("/penjualan/fungsitambah"); ?>", // Isi dengan url/path file php yang dituju
        data: {id_barang : $("#kd_barang").val()}, // data yang akan dikirim ke file yang dituju
        dataType: "json",
        beforeSend: function(e) {
          if(e && e.overrideMimeType) {
            e.overrideMimeType("application/json;charset=UTF-8");
          }
        },
        success: function(response){ 
          $("#harga1").html(response.list_barang).show();

        },
        error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error
          alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error
        }
      });

    });


  });
  </script>
    <script>
    
function convertToRupiah(angka)
{
  var rupiah = '';    
  var angkarev = angka.toString().split('').reverse().join('');
  for(var i = 0; i < angkarev.length; i++) if(i%3 == 0) rupiah += angkarev.substr(i,3)+'.';
  return ''+rupiah.split('',rupiah.length-1).reverse().join('');
}

function sum1() {
      var harga_jual1 = document.getElementById('harga_jual1').value;
      var qwe1 = harga_jual1.replace(".", "");
      var qwe2 = qwe1.replace(".", "");
      var qwe3 = qwe2.replace(".", "");
      var hasil_harga_jual = qwe3.replace(".", "");



      var jumlah_jual1 = document.getElementById('jumlah_jual1').value;
      var q1we1 = jumlah_jual1.replace(".", "");
      var q1we2 = q1we1.replace(".", "");
      var q1we3 = q1we2.replace(".", "");
      var hasil_jumlah_jual = q1we3.replace(".", "");


      if(document.getElementById('harga_jual11')!=null){
        var harga_jual11 = document.getElementById('harga_jual11').value;
        var qwe1 = harga_jual11.replace(".", "");
        var qwe2 = qwe1.replace(".", "");
        var qwe3 = qwe2.replace(".", "");
        var hasil_harga_jual1 = qwe3.replace(".", "");
      }else{
        var hasil_harga_jual1 =0;
      }

      if(document.getElementById('jumlah_jual11')!=null){
        var jumlah_jual11 = document.getElementById('jumlah_jual11').value;
        var qwe1 = jumlah_jual11.replace(".", "");
        var qwe2 = qwe1.replace(".", "");
        var qwe3 = qwe2.replace(".", "");
        var hasil_jumlah_jual1 = qwe3.replace(".", "");
      }else{
        var hasil_jumlah_jual1 =0;
      }

      if(document.getElementById('harga_jual12')!=null){
        var harga_jual12 = document.getElementById('harga_jual12').value;
        var qwe1 = harga_jual12.replace(".", "");
        var qwe2 = qwe1.replace(".", "");
        var qwe3 = qwe2.replace(".", "");
        var hasil_harga_jual2 = qwe3.replace(".", "");
      }else{
        var hasil_harga_jual2 =0;
      }

      if(document.getElementById('jumlah_jual12')!=null){
        var jumlah_jual12 = document.getElementById('jumlah_jual12').value;
        var qwe1 = jumlah_jual12.replace(".", "");
        var qwe2 = qwe1.replace(".", "");
        var qwe3 = qwe2.replace(".", "");
        var hasil_jumlah_jual2 = qwe3.replace(".", "");
      }else{
        var hasil_jumlah_jual2 =0;
      }

      if(document.getElementById('harga_jual13')!=null){
        var harga_jual13 = document.getElementById('harga_jual13').value;
        var qwe1 = harga_jual13.replace(".", "");
        var qwe2 = qwe1.replace(".", "");
        var qwe3 = qwe2.replace(".", "");
        var hasil_harga_jual3 = qwe3.replace(".", "");
      }else{
        var hasil_harga_jual3 =0;
      }

      if(document.getElementById('jumlah_jual13')!=null){
        var jumlah_jual13 = document.getElementById('jumlah_jual13').value;
        var qwe1 = jumlah_jual13.replace(".", "");
        var qwe2 = qwe1.replace(".", "");
        var qwe3 = qwe2.replace(".", "");
        var hasil_jumlah_jual3 = qwe3.replace(".", "");
      }else{
        var hasil_jumlah_jual3 =0;
      }

      



      var result = parseInt(hasil_harga_jual) * parseInt(hasil_jumlah_jual);
      var result2 = parseInt(hasil_harga_jual1) * parseInt(hasil_jumlah_jual1);
      var result3 = parseInt(hasil_harga_jual2) * parseInt(hasil_jumlah_jual2);
      var result4 = parseInt(hasil_harga_jual3) * parseInt(hasil_jumlah_jual3);
      var num = result+result2+result3+result4;
      if (!isNaN(num)) {

         document.getElementById('subtotal1').value = convertToRupiah(result);
         document.getElementById('hasil_total').value = convertToRupiah(num);

      }
}

function sum11() {
      var harga_jual1 = document.getElementById('harga_jual1').value;
      var qwe1 = harga_jual1.replace(".", "");
      var qwe2 = qwe1.replace(".", "");
      var qwe3 = qwe2.replace(".", "");
      var hasil_harga_jual = qwe3.replace(".", "");



      var jumlah_ambil1 = document.getElementById('jumlah_ambil1').value;
      var q1we1 = jumlah_ambil1.replace(".", "");
      var q1we2 = q1we1.replace(".", "");
      var q1we3 = q1we2.replace(".", "");
      var hasil_jumlah_ambil = q1we3.replace(".", "");


      if(document.getElementById('harga_jual11')!=null){
        var harga_jual11 = document.getElementById('harga_jual11').value;
        var qwe1 = harga_jual11.replace(".", "");
        var qwe2 = qwe1.replace(".", "");
        var qwe3 = qwe2.replace(".", "");
        var hasil_harga_jual1 = qwe3.replace(".", "");
      }else{
        var hasil_harga_jual1 =0;
      }

      if(document.getElementById('jumlah_ambil11')!=null){
        var jumlah_ambil11 = document.getElementById('jumlah_ambil11').value;
        var qwe1 = jumlah_ambil11.replace(".", "");
        var qwe2 = qwe1.replace(".", "");
        var qwe3 = qwe2.replace(".", "");
        var hasil_jumlah_ambil1 = qwe3.replace(".", "");
      }else{
        var hasil_jumlah_ambil1 =0;
      }

      if(document.getElementById('harga_jual12')!=null){
        var harga_jual12 = document.getElementById('harga_jual12').value;
        var qwe1 = harga_jual12.replace(".", "");
        var qwe2 = qwe1.replace(".", "");
        var qwe3 = qwe2.replace(".", "");
        var hasil_harga_jual2 = qwe3.replace(".", "");
      }else{
        var hasil_harga_jual2 =0;
      }

      if(document.getElementById('jumlah_ambil12')!=null){
        var jumlah_ambil12 = document.getElementById('jumlah_ambil12').value;
        var qwe1 = jumlah_ambil12.replace(".", "");
        var qwe2 = qwe1.replace(".", "");
        var qwe3 = qwe2.replace(".", "");
        var hasil_jumlah_ambil2 = qwe3.replace(".", "");
      }else{
        var hasil_jumlah_ambil2 =0;
      }

      if(document.getElementById('harga_jual13')!=null){
        var harga_jual13 = document.getElementById('harga_jual13').value;
        var qwe1 = harga_jual13.replace(".", "");
        var qwe2 = qwe1.replace(".", "");
        var qwe3 = qwe2.replace(".", "");
        var hasil_harga_jual3 = qwe3.replace(".", "");
      }else{
        var hasil_harga_jual3 =0;
      }

      if(document.getElementById('jumlah_ambil13')!=null){
        var jumlah_ambil13 = document.getElementById('jumlah_ambil13').value;
        var qwe1 = jumlah_ambil13.replace(".", "");
        var qwe2 = qwe1.replace(".", "");
        var qwe3 = qwe2.replace(".", "");
        var hasil_jumlah_ambil3 = qwe3.replace(".", "");
      }else{
        var hasil_jumlah_ambil3 =0;
      }

      



      var result = parseInt(hasil_harga_jual) * parseInt(hasil_jumlah_ambil);
      var result2 = parseInt(hasil_harga_jual1) * parseInt(hasil_jumlah_ambil1);
      var result3 = parseInt(hasil_harga_jual2) * parseInt(hasil_jumlah_ambil2);
      var result4 = parseInt(hasil_harga_jual3) * parseInt(hasil_jumlah_ambil3);
      var num = result+result2+result3+result4;
      if (!isNaN(num)) {

         document.getElementById('subtotal1').value = convertToRupiah(result);
         document.getElementById('hasil_total').value = convertToRupiah(num);

      }
}

 
</script>




<script>
    
function convertToRupiah(angka)
{
  var rupiah = '';    
  var angkarev = angka.toString().split('').reverse().join('');
  for(var i = 0; i < angkarev.length; i++) if(i%3 == 0) rupiah += angkarev.substr(i,3)+'.';
  return ''+rupiah.split('',rupiah.length-1).reverse().join('');
}

function sumt() {
      var subtota = document.getElementById('subtota').value;
      var qwe1 = subtota.replace(".", "");
      var qwe2 = qwe1.replace(".", "");
      var qwe3 = qwe2.replace(".", "");
      var subtota = qwe3.replace(".", "");

      var diskon = document.getElementById('diskon').value;
      var qwe1 = diskon.replace(".", "");
      var qwe2 = qwe1.replace(".", "");
      var qwe3 = qwe2.replace(".", "");
      var diskon = qwe3.replace(".", "");

      var bayar = document.getElementById('bayar').value;
      var q1we1 = bayar.replace(".", "");
      var q1we2 = q1we1.replace(".", "");
      var q1we3 = q1we2.replace(".", "");
      var bayar = q1we3.replace(".", "");

      var kembalian = document.getElementById('kembalian').value;
      var q1we1 = kembalian.replace(".", "");
      var q1we2 = q1we1.replace(".", "");
      var q1we3 = q1we2.replace(".", "");
      var kembalian = q1we3.replace(".", "");

      var result = parseInt(subtota) - parseInt(diskon);
      var grandtotal = result;
      if (!isNaN(grandtotal)) {

         document.getElementById('grandtotal').value = convertToRupiah(grandtotal);

      }
}
function sumr() {
      var subtota = document.getElementById('subtota').value;
      var qwe1 = subtota.replace(".", "");
      var qwe2 = qwe1.replace(".", "");
      var qwe3 = qwe2.replace(".", "");
      var subtota = qwe3.replace(".", "");

      var diskon = document.getElementById('diskon').value;
      var qwe1 = diskon.replace(".", "");
      var qwe2 = qwe1.replace(".", "");
      var qwe3 = qwe2.replace(".", "");
      var diskon = qwe3.replace(".", "");

      var bayar = document.getElementById('bayar').value;
      var q1we1 = bayar.replace(".", "");
      var q1we2 = q1we1.replace(".", "");
      var q1we3 = q1we2.replace(".", "");
      var bayar = q1we3.replace(".", "");

      var kembalian = document.getElementById('kembalian').value;
      var q1we1 = kembalian.replace(".", "");
      var q1we2 = q1we1.replace(".", "");
      var q1we3 = q1we2.replace(".", "");
      var kembalian = q1we3.replace(".", "");

      var result = parseInt(subtota) - parseInt(diskon);
      var result2 = parseInt(bayar)-parseInt(result);
      var kembalian = result2;
      if (!isNaN(kembalian)) {

         document.getElementById('kembalian').value = convertToRupiah(kembalian);

      }
}

 
</script>