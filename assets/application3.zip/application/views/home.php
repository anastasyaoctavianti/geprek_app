



<section>

    <div class="slider_img layout_two">
        <div id="carousel" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carousel" data-slide-to="0" class="active"></li>
                <li data-target="#carousel" data-slide-to="1"></li>
                <li data-target="#carousel" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner" role="listbox">
                <div class="carousel-item active">
                    <img class="d-block" src="<?php echo base_url().'assets/toko4.jpg'?>" alt="First slide">
                    <div class="carousel-caption d-md-block">
                        <div class="slider_title">
                        
                        
                        </div>
                    </div>
                </div>
               
          
            </div>
        
        </div>
    </div>
</section>




<!--//END OUR COURSES -->
<!--============================= EVENTS =============================-->

<!--//END EVENTS -->
<!--============================= DETAILED CHART =============================-->

<!--//END DETAILED CHART -->
<!--============================= FOOTER =============================-->






<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="foot-logo">
                    <center><a href="<?php echo site_url();?>">
                        <img src="<?php echo base_url().'assets/log.png'?>" width="100px" class="img-fluid" alt="footer_logo">
                    </a>
                    <p>APLIKASI MANAJEMEN PENJUALAN DAN KEUANGAN BERBASIS WEB PADA CV. DATACOM</p></center>
                    </div>
                </div>
                              
                <div class="col-md-4">
                 
                </div>

              
                
                <div class="col-md-4">
                    <div class="address">
                        <h3>Alamat</h3>
                        <p>JL. KAMPUNG MELAYU BARAT NO.78, RT.10, Melayu, Kec. Banjarmasin Tengah, Kota Banjarmasin, Kalimantan Selatan 70232</p>
                        
                        </div>
                    </div>

                </div>
            </div>
        </footer>
        <!--//END FOOTER -->
        <!-- jQuery, Bootstrap JS. -->
        <script src="<?php echo base_url().'theme/js/jquery.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/tether.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/bootstrap.min.js'?>"></script>
        <!-- Plugins -->
        <script src="<?php echo base_url().'theme/js/slick.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/waypoints.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/counterup.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/owl.carousel.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/validate.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/tweetie.min.js'?>"></script>
        <!-- Subscribe -->
        <script src="<?php echo base_url().'theme/js/subscribe.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/jquery-ui-1.10.4.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/jquery.isotope.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/animated-masonry-gallery.js'?>"></script>
        <!-- Magnific popup JS -->
        <script src="<?php echo base_url().'theme/js/jquery.magnific-popup.js'?>"></script>
        <!-- Script JS -->
        <script src="<?php echo base_url().'theme/js/script.js'?>"></script>
        
            <script src="<?php echo base_url().'theme/js/jquery.dataTables.min.js'?>"></script>
            <script src="<?php echo base_url().'theme/js/dataTables.bootstrap4.min.js'?>"></script>
            <script src="<?php echo base_url();?>assets/alert/query.js"></script>
              <script>
                 $( '.uang' ).mask('00.000.000.000', {reverse: true});
              $(document).ready(function() {
                $('#display').DataTable();
              });
            </script>



    </body>

    </html>
