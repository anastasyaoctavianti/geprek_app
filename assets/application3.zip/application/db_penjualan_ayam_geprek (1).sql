-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2023 at 03:49 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_penjualan_ayam_geprek`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang_list`
--

CREATE TABLE `barang_list` (
  `id_barang_list` int(11) NOT NULL,
  `id_penjualan` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `jumlah_jual` int(11) NOT NULL,
  `id_pegawai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang_list`
--

INSERT INTO `barang_list` (`id_barang_list`, `id_penjualan`, `id_barang`, `jumlah_jual`, `id_pegawai`) VALUES
(91, 1, 3, 2, 1),
(92, 1, 6, 1, 1),
(96, 2, 16, 1, 6),
(97, 2, 0, 0, 6);

-- --------------------------------------------------------

--
-- Table structure for table `barang_list2`
--

CREATE TABLE `barang_list2` (
  `id_barang_list2` int(11) NOT NULL,
  `id_complement_karyawan` int(11) NOT NULL,
  `id_menu_makanan` int(11) NOT NULL,
  `jumlah_ambil` int(11) NOT NULL,
  `tanggal_ambil` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barang_list2`
--

INSERT INTO `barang_list2` (`id_barang_list2`, `id_complement_karyawan`, `id_menu_makanan`, `jumlah_ambil`, `tanggal_ambil`) VALUES
(8, 1, 6, 3, '2023-02-02'),
(9, 1, 10, 1, '2023-02-02'),
(10, 2, 19, 1, '2023-02-02');

-- --------------------------------------------------------

--
-- Table structure for table `complement_karyawan`
--

CREATE TABLE `complement_karyawan` (
  `id_complement_karyawan` int(11) NOT NULL,
  `id_menu_makanan` varchar(50) NOT NULL,
  `jumlah_ambil` int(11) NOT NULL,
  `tanggal_ambil` date NOT NULL,
  `id_menu_makanan1` int(11) NOT NULL,
  `id_menu_makanan2` int(11) NOT NULL,
  `id_menu_makanan3` int(11) NOT NULL,
  `jumlah_ambil1` int(11) NOT NULL,
  `jumlah_ambil2` int(11) NOT NULL,
  `jumlah_ambil3` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `complement_karyawan`
--

INSERT INTO `complement_karyawan` (`id_complement_karyawan`, `id_menu_makanan`, `jumlah_ambil`, `tanggal_ambil`, `id_menu_makanan1`, `id_menu_makanan2`, `id_menu_makanan3`, `jumlah_ambil1`, `jumlah_ambil2`, `jumlah_ambil3`, `keterangan`, `total`) VALUES
(1, '6', 3, '2023-02-02', 10, 0, 0, 1, 0, 0, '', 57000),
(2, '19', 1, '2023-02-02', 0, 0, 0, 0, 0, 0, '', 10000);

-- --------------------------------------------------------

--
-- Table structure for table `menu_makanan`
--

CREATE TABLE `menu_makanan` (
  `id_menu_makanan` int(11) NOT NULL,
  `kode_menu` varchar(40) NOT NULL,
  `nama_menu` text NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu_makanan`
--

INSERT INTO `menu_makanan` (`id_menu_makanan`, `kode_menu`, `nama_menu`, `harga`) VALUES
(2, '102', 'Fried Chicken Paha Bawah / Sayap', 12000),
(3, '103', 'Fried Chicken Paha Atas / Dada', 15000),
(6, '104', 'Ayam Geprek Paha Bawah / Sayap', 14000),
(8, '105', 'Ayam Geprek Paha Atas / Dada', 17000),
(9, '201', 'Nasi Goreng Spesial', 18000),
(10, '202', 'Mie Goreng Spesial', 15000),
(11, '203', 'Kwetiaw Goreng Spesial', 17000),
(12, '301', 'Chicken Steak', 16000),
(13, '302', 'Chicken Strip', 15000),
(14, '303', 'Chicken Cheese Burger', 17000),
(15, '304', 'Chicken Teriyaki (Include Nasi)', 15000),
(16, '401', 'Terong Crispy', 5000),
(17, '402', 'Lele Crispy', 10000),
(18, '403', 'Jamur Crispy', 10000),
(19, '404', 'Tahu Crispy', 10000),
(20, '501', 'Original / Crispy Saus Kurma', 17000),
(21, '502', 'Nasi', 4000),
(22, '503', 'Onion Ring', 8000),
(23, '504', 'Ayam Penyet', 20000),
(24, '505', 'Perkedel', 5000),
(25, '901', 'Paket Super Hemat 1 (Fried Chicken Sayap/Paha Bawah + Nasi + Es Teh)', 17000),
(26, '902', 'Paket Super Hemat 2 (Fried Chicken Dada/Paha Atas + Nasi + Es Teh)', 20000),
(27, '903', 'Paket Super Hemat 3 (Ayam Geprek Sayap/Paha Bawah + Nasi + Es Teh)', 20000),
(28, '904', 'Paket Super Hemat 4 (Ayam Geprek Dada/Paha Atas + Nasi + Es Teh)', 25000),
(29, '905', 'Paket Super Hemat 5 (Ayam Geprek Dada Tanpa Tulang + Nasi + Es Teh)', 22000),
(30, '906', 'Paket Anak Sholeh 1 (Nasi + Paha Bawah + Milo)', 21000),
(31, '907', 'Paket Anak Sholeh 2 (Nasi Goreng Sayap + Milo)', 25000),
(32, '908', 'Paket Anak Sholeh 3 (Chicken Cheese Burger + Milo)', 22000),
(33, '909', 'Paket Palestina 1 (Chicken Steak + Nasi + Teh Botol)', 25000),
(34, '910', 'Paket Palestina 2 (Chicken Steak + Kentang + Teh Botol)', 23000),
(35, '701', 'Teh Panas/Es', 4000),
(36, '702', 'Jeruk Panas/Es ', 6000),
(37, '703', 'Teh Botol/Tebs/Fruit Tea', 6000),
(38, '704', 'Air Mineral Botol', 5000),
(39, '705', 'Lemon tea Panas/Es', 6000),
(40, '706', 'Milo Panas/Es ', 9000),
(41, '707', 'Cappucino Panas/Es', 10000),
(42, '708', 'Milkshake (Cokelat/Vanilla/Strawberry)', 12000),
(43, '709', 'Ice Cream', 4000),
(44, '710', 'Aneka Jus', 15000);

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `id_pegawai` int(11) NOT NULL,
  `nama_pegawai` varchar(100) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jenis_kelamin` varchar(30) NOT NULL,
  `nomor_hp` text NOT NULL,
  `jabatan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`id_pegawai`, `nama_pegawai`, `tempat_lahir`, `tanggal_lahir`, `jenis_kelamin`, `nomor_hp`, `jabatan`) VALUES
(1, 'Dea Nita Ariani', 'Banjarbaru', '1999-12-05', 'Perempuan', '+62 895-7007-16413', 'Supervisor'),
(2, 'Akhmad Khusyairi', 'Astambul', '2000-09-13', 'Laki-Laki', '+62 858-4952-8706', 'Supervisor'),
(3, 'Jamalludin', 'Kandangan', '1999-06-27', 'Laki-Laki', '+62 857-1532-2693', 'Cook'),
(6, 'Fadli Rahman', 'Pingaran', '1999-01-29', 'Laki-Laki', '+62 888-0410-2698', 'Cook'),
(7, 'Fajri', 'Martapura', '2000-10-07', 'Laki-Laki', '+62 831-5172-8482', 'Cook'),
(8, 'M. Faishal Ali', 'Kalampaian', '2001-11-05', 'Laki-Laki', '+62 816-4978-0966', 'Dishwasher'),
(9, 'M. Noor', 'Martapura', '2000-12-30', 'Laki-Laki', '+62 857-0978-2691', 'Dishwasher'),
(10, 'Rasita', 'Cindai Alus', '2000-09-23', 'Perempuan', '+62 851-7209-2309', 'Kasir'),
(11, 'Norkamalia', 'Kalampaian Ulu', '2000-08-20', 'Perempuan', '+62 895-3385-42781', 'Kasir'),
(12, 'Anastasya Octavianti', 'Bandung', '2000-10-14', 'Perempuan', '+62 858-2067-2045', 'Kasir'),
(13, 'Dhea', 'Banjarbaru', '2003-04-05', 'Perempuan', '+62 877-7978-5146', 'Server Waitress'),
(14, 'Nor Hidayati', 'Martapura', '2001-03-01', 'Perempuan', '+62 821-5212-3417', 'Server Waitress'),
(15, 'Betiani', 'Panarukan', '2003-11-05', 'Perempuan', '+62 822-5259-4166', 'Server Waitress');

-- --------------------------------------------------------

--
-- Table structure for table `pengeluaran`
--

CREATE TABLE `pengeluaran` (
  `id_pengeluaran` int(11) NOT NULL,
  `nama_pengeluaran` varchar(100) NOT NULL,
  `biaya_pengeluaran` int(11) NOT NULL,
  `tanggal_pengeluaran` date NOT NULL,
  `keterangan_lain` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengeluaran`
--

INSERT INTO `pengeluaran` (`id_pengeluaran`, `nama_pengeluaran`, `biaya_pengeluaran`, `tanggal_pengeluaran`, `keterangan_lain`) VALUES
(3, 'Pengeluaran Lainnya...', 3000000, '2022-10-20', 'Transfer ke Office'),
(4, 'Pengeluaran Lainnya...', 232000, '2022-10-21', 'Bahan sayur dan sayuran\r\n'),
(5, 'ATK', 52000, '2022-10-22', ''),
(13, 'Pengeluaran Lainnya...', 675000, '2022-10-22', 'Pembelian tepung,gas 12kg,pembungkus \r\n'),
(14, 'Pengeluaran Lainnya...', 310000, '2022-10-23', 'Beras'),
(15, 'ATK', 55000, '2022-10-23', 'fotocopy laporan , data gudang'),
(16, 'Pengeluaran Lainnya...', 100000, '2022-10-23', 'pembungkus '),
(17, 'Pengeluaran Lainnya...', 76000, '2022-10-24', 'Pembersih'),
(18, 'ATK', 97000, '2022-10-24', ''),
(19, 'Pengeluaran Lainnya...', 310000, '2022-10-25', 'beras'),
(20, 'Gaji Karyawan', 22450000, '2022-10-25', 'Gaji Pokok, Tunjangan Jabatan,,Tunjangan Class\r\n'),
(21, 'Pengeluaran Lainnya...', 454000, '2022-10-26', 'bahan pelengkap,bahan minuman,pembungkus'),
(22, 'WIFI', 355000, '2022-10-26', ''),
(23, 'Pengeluaran Lainnya...', 98000, '2022-10-27', 'Pembungkus '),
(24, 'ATK', 35000, '2022-10-27', ''),
(25, 'Pengeluaran Lainnya...', 755000, '2022-10-28', 'Beras,pembungkus,bahan marinasi ayam'),
(26, 'Pengeluaran Lainnya...', 358000, '2022-10-28', 'Gas dan pembersih'),
(27, 'Pengeluaran Lainnya...', 258000, '2022-10-29', 'pembelian bahan ayam'),
(28, 'ATK', 74000, '2022-10-29', ''),
(29, 'Pengeluaran Lainnya...', 310000, '2022-10-30', 'Bahan sayur dan sayuran'),
(30, 'Pengeluaran Lainnya...', 3650000, '2022-10-31', 'pembungkus,bahan sayur, transfer ke office\r\n'),
(31, 'Pengeluaran Lainnya...', 210000, '2022-11-01', 'Pembelian Bahan minuman dan pembersih'),
(32, 'Pengeluaran Lainnya...', 77000, '2022-11-02', 'Bumbu groceries'),
(33, 'ATK', 120000, '2022-11-02', ''),
(34, 'WIFI', 310000, '2022-11-03', ''),
(35, 'Pengeluaran Lainnya...', 454000, '2022-11-04', 'Pembelian Gas,bahan sayur\r\n'),
(36, 'Pengeluaran Lainnya...', 188000, '2022-11-05', 'Bahan Minuman , pembersih'),
(37, 'ATK', 88000, '2022-11-06', ''),
(38, 'Pengeluaran Lainnya...', 210000, '2022-11-06', 'bahan minuman , pembungkus'),
(39, 'Pengeluaran Lainnya...', 310000, '2022-11-07', 'Bumbu groceries'),
(40, 'Pengeluaran Lainnya...', 320000, '2022-11-08', 'Sayuran , dll'),
(41, 'ATK', 100000, '2022-11-09', ''),
(42, 'PDAM', 250000, '2022-11-09', '\r\n'),
(43, 'Pengeluaran Lainnya...', 200000, '2022-11-09', 'Pembelian Service tang , service warmer\r\n'),
(44, 'ATK', 50000, '2022-11-10', ''),
(45, 'Pengeluaran Lainnya...', 350000, '2022-11-11', 'Pembelian Sendok dan garpu, bahan sayur\r\n'),
(48, 'Pengeluaran Lainnya...', 88000, '2022-11-12', 'Pembelian kuota'),
(49, 'Pengeluaran Lainnya...', 341600, '2022-11-12', 'Pembayaran pajak \r\n'),
(50, 'Pengeluaran Lainnya...', 50000, '2022-11-13', 'Lembur SPV'),
(51, 'Pengeluaran Lainnya...', 250000, '2022-11-13', 'Pembelian sayuran, minyak goreng, es batu '),
(53, 'Pengeluaran Lainnya...', 3000000, '2022-11-14', 'Transfer Office'),
(56, 'Pengeluaran Lainnya...', 500000, '2022-11-15', 'Belanja sayuran,Gas 12kg'),
(57, 'ATK', 55000, '2022-11-16', 'Kirim laporan ke office, fotocopy laporan kasir'),
(59, 'Pengeluaran Lainnya...', 791000, '2022-11-17', 'Beras,Tepung\r\n'),
(62, 'Pengeluaran Lainnya...', 791000, '2022-11-18', 'Bahan minuman,bahan sayur,bahan ayam'),
(66, 'ATK', 55000, '2022-11-18', '');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_lengkap` text NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` varchar(22) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `username`, `password`, `nama_lengkap`, `alamat`, `no_hp`, `level`) VALUES
(1, 'Admin', '$2y$10$lJi41Pe..fbKAe/Lt6Wb5.iLbbSfaA2FEIwQgUb2h10BtKK8VRdJ.', 'Administrator', '', '', 'admin'),
(2, 'supervisor', '$2y$10$lgSd/Atr2kGnNbfRO6//4uHHPZGk9haWtI./F03cxC.z35PJkOmjG', 'supervisor', '', '', 'supervisor');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `id_penjualan` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `id_pegawai` int(11) NOT NULL,
  `jumlah_jual` int(11) NOT NULL,
  `tanggal_jual` date NOT NULL,
  `id_barang1` int(5) NOT NULL,
  `id_barang2` int(5) NOT NULL,
  `id_barang3` int(5) NOT NULL,
  `jumlah_jual1` int(5) NOT NULL,
  `jumlah_jual2` int(5) NOT NULL,
  `jumlah_jual3` int(5) NOT NULL,
  `total` int(11) NOT NULL,
  `diskon` int(11) NOT NULL,
  `bayar` int(11) NOT NULL,
  `kembalian` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`id_penjualan`, `id_barang`, `id_pegawai`, `jumlah_jual`, `tanggal_jual`, `id_barang1`, `id_barang2`, `id_barang3`, `jumlah_jual1`, `jumlah_jual2`, `jumlah_jual3`, `total`, `diskon`, `bayar`, `kembalian`) VALUES
(1, 3, 1, 2, '2023-02-02', 6, 0, 0, 1, 0, 0, 44000, 0, 50000, 6000),
(2, 16, 6, 1, '2023-02-02', 0, 0, 0, 0, 0, 0, 5000, 0, 5000, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang_list`
--
ALTER TABLE `barang_list`
  ADD PRIMARY KEY (`id_barang_list`);

--
-- Indexes for table `barang_list2`
--
ALTER TABLE `barang_list2`
  ADD PRIMARY KEY (`id_barang_list2`);

--
-- Indexes for table `complement_karyawan`
--
ALTER TABLE `complement_karyawan`
  ADD PRIMARY KEY (`id_complement_karyawan`);

--
-- Indexes for table `menu_makanan`
--
ALTER TABLE `menu_makanan`
  ADD PRIMARY KEY (`id_menu_makanan`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id_pegawai`);

--
-- Indexes for table `pengeluaran`
--
ALTER TABLE `pengeluaran`
  ADD PRIMARY KEY (`id_pengeluaran`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id_penjualan`),
  ADD KEY `id_barang` (`id_barang`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang_list`
--
ALTER TABLE `barang_list`
  MODIFY `id_barang_list` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `barang_list2`
--
ALTER TABLE `barang_list2`
  MODIFY `id_barang_list2` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `complement_karyawan`
--
ALTER TABLE `complement_karyawan`
  MODIFY `id_complement_karyawan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `menu_makanan`
--
ALTER TABLE `menu_makanan`
  MODIFY `id_menu_makanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `id_pegawai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `pengeluaran`
--
ALTER TABLE `pengeluaran`
  MODIFY `id_pengeluaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `id_penjualan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
